<?php
    define("DB_HOST", "");
    define("DB_USER", "");
    define("DB_PASSWORD", "");
    define("DB_NAME", "ekhtar");
    ?>