<?php
 
/*
 * Following code will list all the questions
 */
 
// array for JSON response
$response = array();
 
// include db connect class
require_once __DIR__ . '/db_connect.php';
 
// connecting to db
$db = new DB_CONNECT();
 
// get all questions from questions table
$result = mysql_query("SELECT *FROM questions") or die(mysql_error());
 
// check for empty result
if (mysql_num_rows($result) > 0) {
    // looping through all results
    // questions node
    $response["questions"] = array();
 
    while ($row = mysql_fetch_array($result)) {
        // temp user array
        $question = array();
        $question["qid"] = utf8_decode($row["qid"]);
        $question["uid"] = utf8_decode($row["uid"]);
        $question["qcreated"] = utf8_decode($row["qcreated"]);
        $question["qvalidity"] = utf8_decode($row["qvalidity"]);
        $question["content"] = utf8_decode($row["content"]);
        $question["ch1"] = utf8_decode($row["ch1"]);
        $question["ch2"] = utf8_decode($row["ch2"]);
        $question["ch3"] = utf8_decode($row["ch3"]);
        $question["ch4"] = utf8_decode($row["ch4"]);
        $question["ch5"] = utf8_decode($row["ch5"]);
 
        // push single question into final response array
        array_push($response["questions"], $question);
    }
    // success
    $response["success"] = 1;
 
    // echoing JSON response
    echo json_encode($response);


} else {
    // no questions found
    $response["success"] = 0;
    $response["message"] = "No questions found";
 
    // echo no users JSON
    echo json_encode($response);
}
?>