<?php
 
/*
 * Following code will update a question information
 * A question is identified by question id (pid)
 */
 
// array for JSON response
$response = array();
 
// check for required fields
if (isset($_POST['uid']) && isset($_POST['content']) && isset($_POST['ch1']) && isset($_POST['ch2'])) {
 
    $uid = $_POST['uid'];
    $qcreated = $_POST['qcreated'];
    $qvalidity = $_POST['qvalidity'];
    $content = $_POST['content'];
    $ch1 = $_POST['ch1'];
    $ch2 = $_POST['ch2'];
    $ch3 = $_POST['ch3'];
    $ch4 = $_POST['ch4'];
    $ch5 = $_POST['ch5'];
 
    // include db connect class
    require_once __DIR__ . '/db_connect.php';
 
    // connecting to db
    $db = new DB_CONNECT();
 
    // mysql update row with matched pid
    $result = mysql_query("UPDATE questions SET content = '$content', ch1 = '$ch1' , ch2 = '$ch2' , ch3 = '$ch3' , ch4 = '$ch4' , ch5 = '$ch5' ,WHERE content = $content");
 
    // check if row inserted or not
    if ($result) {
        // successfully updated
        $response["success"] = 1;
        $response["message"] = "question successfully updated.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
 
    }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}
?>