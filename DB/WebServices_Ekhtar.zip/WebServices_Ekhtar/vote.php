<?php
 
/*
 * Following code will update a question information
 * A question is identified by question id (pid)
 */
 
// array for JSON response
$response = array();
 
// check for required fields
if (isset($_POST['uid']) && isset($_POST['qid']) && isset($_POST['choix'])) {
 
    $uid = $_POST['uid'];
    $qid = $_POST['qid'];
    $choix = $_POST['choix'];
    
 
    // include db connect class
    require_once __DIR__ . '/db_connect.php';
 
    // connecting to db
    $db = new DB_CONNECT();
 
    // mysql update row with matched pid
    $result = mysql_query("INSERT INTO vote (idv, qid, uid, choix) VALUES (NULL,'$qid' ,'$uid' ,'$choix')");
 
    // check if row inserted or not
    if ($result) {
        // successfully updated
        $response["success"] = 1;
        $response["message"] = "Vote successfully added.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
 
    }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}
?>