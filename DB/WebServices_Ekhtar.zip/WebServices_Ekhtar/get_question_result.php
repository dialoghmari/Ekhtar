<?php
 
/*
 * Following code will get single question details
 * A question is identified by question id (qid)
 */
 
// array for JSON response
$response = array();
 
// include db connect class
require_once __DIR__ . '/db_connect.php';
 
// connecting to db
$db = new DB_CONNECT();
 
// check for post data
if (isset($_GET["qid"])) {
    $qid = (int)$_GET['qid'];
    $resultat = array();
    $nombrevote = 0;
    $ch1p =0;
    $ch2p =0;
    $ch3p =0;
    $ch4p =0;
    $ch5p =0;
    $validity="";
    
    

    // get nombreVote
    $result = mysql_query("SELECT count(choix) as nombrevote from vote where qid= $qid");
    $row = mysql_fetch_assoc($result);
    $nombrevote = $row['nombrevote'];
    $resultat["nombrevote"] = round($nombrevote);

    // get ch1p
    $result = mysql_query("SELECT count(choix) as ch1r from vote where qid= $qid and choix='ch1'");
    $row = mysql_fetch_assoc($result);
    $ch1p = $row['ch1r'] * 100 / $nombrevote;
    $resultat["ch1p"] = round($ch1p);

    // get ch2p
    $result = mysql_query("SELECT count(choix) as ch2r from vote where qid= $qid and choix='ch2'");
    $row = mysql_fetch_assoc($result);
    $ch2p = $row['ch2r'] * 100 / $nombrevote;
    $resultat["ch2p"] = round($ch2p);

    // get ch3p
    $result = mysql_query("SELECT count(choix) as ch3r from vote where qid= $qid and choix='ch3'");
    $row = mysql_fetch_assoc($result);
    $ch3p = $row['ch3r'] * 100 / $nombrevote;
    $resultat["ch3p"] = round($ch3p);

    // get ch4p
    $result = mysql_query("SELECT count(choix) as ch4r from vote where qid= $qid and choix='ch4'");
    $row = mysql_fetch_assoc($result);
    $ch4p = $row['ch4r'] * 100 / $nombrevote;
    $resultat["ch4p"] = round($ch4p);

    // get ch5p
    $result = mysql_query("SELECT count(choix) as ch5r from vote where qid= $qid and choix='ch5'");
    $row = mysql_fetch_assoc($result);
    $ch5p = $row['ch5r'] * 100 / $nombrevote;
    $resultat["ch5p"] = round($ch5p);

    /* get validity
    $result = mysql_query("SELECT qvalidity FROM questions where qid = $qid");
    $row = mysql_fetch_assoc($result);
    $validity = $row['qvalidity'];
    $resultat["validity"] = $validity;*/
    

    $response["success"] = 1;
    $response["resultat"] = array();
    array_push($response["resultat"], $resultat);
    echo json_encode($response);
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}
?>