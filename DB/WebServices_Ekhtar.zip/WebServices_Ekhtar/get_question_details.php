<?php
 
/*
 * Following code will get single question details
 * A question is identified by question id (qid)
 */
 
// array for JSON response
$response = array();
 
// include db connect class
require_once __DIR__ . '/db_connect.php';
 
// connecting to db
$db = new DB_CONNECT();
 
// check for post data
if (isset($_GET["categorie"]) && isset($_GET["uid"])) {

    $uid = $_GET["uid"];
    $categorie = $_GET["categorie"];

    if($_GET["categorie"] == "recent")
    {
        $requete = "SELECT * FROM questions q WHERE NOT EXISTS ( SELECT 1 FROM vote v WHERE q.qid = v.qid AND v.uid=$uid ) BY ORDER BY RAND() LIMIT 1";    
    }else
    {   
        $requete = "SELECT * FROM questions q WHERE categorie='$categorie' and NOT EXISTS ( SELECT 1 FROM vote v WHERE q.qid = v.qid AND v.uid=$uid ) ORDER BY RAND() LIMIT 1";
    }
    $result = mysql_query($requete);
 
    if (!empty($result)) {
        // check for empty result
        if (mysql_num_rows($result) > 0) {
 
            $result = mysql_fetch_array($result);
 
            $question = array();
            $question["qid"] = utf8_decode($result["qid"]);
            $question["uid"] = utf8_decode($result["uid"]);
            $question["qcreated"] = utf8_decode($result["qcreated"]);
            $question["qvalidity"] = utf8_decode($result["qvalidity"]);
            $question["content"] = utf8_decode($result["content"]);
            $question["ch1"] = utf8_decode($result["ch1"]);
            $question["ch2"] = utf8_decode($result["ch2"]);
            $question["ch3"] = utf8_decode($result["ch3"]);
            $question["ch4"] = utf8_decode($result["ch4"]);
            $question["ch5"] = utf8_decode($result["ch5"]);
            $question["nombrechoix"] = utf8_decode($result["nombrechoix"]);

            // success
            $response["success"] = 1;
 
            // user node
            $response["question"] = array();
 
            array_push($response["question"], $question);
 
            // echoing JSON response
            echo json_encode($response);
        } else {
            // no question found
            $response["success"] = 0;
            $response["message"] = "No question found";
 
            // echo no users JSON
            echo json_encode($response);
        }
    } else {
        // no question found
        $response["success"] = 0;
        $response["message"] = "No question found";
 
        // echo no users JSON
        echo json_encode($response);
    }
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}
?>